<?php
require("user.php");
require("util.php");

$conn = new Conn;

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    echo file_get_contents("static/login.html");
} else if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (array_key_exists("username", $_POST) && array_key_exists("password", $_POST)) {
        $temp = unserialize(base64_decode($_POST["password"]));
        if ($temp && $temp->username === $_POST["username"]) {
            $conn->query = "select username, uuid from users where username = :username and uuid = :uuid";
            $conn->params = array(":username" => $temp->username, ":uuid" => $temp->uuid);
            $result = $conn->query();
            if ($result && $result["username"] === $_POST["username"]) {
                setcookie("password", $_POST["password"]);
                header("Location: /");
            }
        }
    }
    die("Invalid credentials.");
}
?>
