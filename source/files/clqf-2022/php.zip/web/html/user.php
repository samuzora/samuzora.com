<?php
class User {
    public $picture;
    public $username;
    public $uuid;

    public function __construct(string $username, string $uuid) {
        $this->username = $username;
        $this->picture = "static/phrog.gif";
        $this->uuid = $uuid;
    }
    
    public function whoami() {
        $picture = base64_encode(file_get_contents($this->picture));
        return "
            <div class='card' style='width: 50%'>
                <img class='card-img-top' src='data:image/gif;base64,{$picture}' class='rounded' alt='phrog'>
                <div class='card-body'>
                    <h5 class='card-title'>User: {$this->username}</h5>
                    <p>uuid: {$this->uuid}</p>
                </div>
            </div>
        ";
    }
}
?>
