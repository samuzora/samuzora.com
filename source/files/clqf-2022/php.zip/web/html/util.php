<?php
class Conn {
    public $query;
    public $params;

    public function __call(string $name, array $arguments) {
        $conn = new SQLite3("/sqlite3/db");
        $query = $this->query;
        foreach ($this->params as $key=>$value) {
            $value = $conn->escapeString($value);
            $query = str_replace($key, "'$value'", $query);
        }

        // in case we ever need to execute multiple queries
        $queries = explode("; ", $query);
        foreach ($queries as $temp) {
            $result = $conn->query($temp);
        }
        if ($result !== false) {
            if ($result->numColumns()) {
                return $result->fetchArray();
            } else {
                return true;
            }
        } else {
            return $result;
        }
    }
}
?>
