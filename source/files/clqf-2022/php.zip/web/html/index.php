<?php
require("user.php");
require("util.php");

$conn = new Conn;

if (array_key_exists("password", $_COOKIE) === false) {
    echo file_get_contents("static/index.html");
    die();
}
$temp = unserialize(base64_decode($_COOKIE["password"]));
$conn->query = "select username, uuid from users where uuid = :uuid";
$conn->params = array(":uuid" => $temp->uuid);
$result = $conn->query();
if ($result) {
    $user = $temp;
} else {
    header("Location: /login.php");
}
?>

<!DOCTYPE html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container mt-5 px-auto">
        <div class="row">
            <div class="col">
                 <?php echo $user->whoami(); ?>
            </div>
            <div class="col">
                <p>I hope u like phrogs</p>
            </div>
        </div>
    </div>
</body>
